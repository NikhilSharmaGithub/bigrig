"use server";

import { redirect, unstable_rethrow } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import {
  createSession,
  destroySession,
  hashPassword,
  isAdminEmail,
  isValidAdminSetupCode,
  verifyPassword,
} from "@/lib/auth";
import { mergeGuestCartIntoUser } from "@/lib/cart";
import { safeNextPath } from "@/lib/next-path";
import { sendWelcomeEmail } from "@/lib/email";

export type AuthState = { error?: string };

const UNAVAILABLE =
  "Sign-in is temporarily unavailable. Please try again in a few minutes.";

/**
 * Runs an auth action, turning a database/connection failure (e.g. no
 * DATABASE_URL on a deploy) into a friendly form error instead of the global
 * error page. Next's redirect()/notFound() signals are re-thrown untouched.
 */
async function guarded(
  name: string,
  run: () => Promise<AuthState>,
): Promise<AuthState> {
  try {
    return await run();
  } catch (e) {
    unstable_rethrow(e);
    console.error(`${name} failed`, e);
    return { error: UNAVAILABLE };
  }
}

function clean(v: FormDataEntryValue | null): string {
  return String(v ?? "").trim();
}

export async function registerAction(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  return guarded("registerAction", () => register(formData));
}

async function register(formData: FormData): Promise<AuthState> {
  const name = clean(formData.get("name"));
  const email = clean(formData.get("email")).toLowerCase();
  const password = String(formData.get("password") ?? "");

  if (!email || !password) {
    return { error: "Email and password are required." };
  }
  if (password.length < 8) {
    return { error: "Password must be at least 8 characters." };
  }
  // Owner emails are claimed only through /admin-login with the setup code.
  if (isAdminEmail(email)) {
    return { error: "This email is reserved. Use the admin sign-in page." };
  }

  const existing = await db.query.users.findFirst({
    where: eq(users.email, email),
    columns: { id: true },
  });
  if (existing) {
    return { error: "An account with this email already exists." };
  }

  const [user] = await db
    .insert(users)
    .values({
      email,
      name: name || null,
      passwordHash: await hashPassword(password),
    })
    .returning({ id: users.id });

  await createSession(user.id);
  await mergeGuestCartIntoUser(user.id);
  void sendWelcomeEmail(email, name || null);
  redirect(safeNextPath(formData.get("next")) ?? "/account");
}

export async function loginAction(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  return guarded("loginAction", () => login(formData));
}

async function login(formData: FormData): Promise<AuthState> {
  const email = clean(formData.get("email")).toLowerCase();
  const password = String(formData.get("password") ?? "");

  if (!email || !password) {
    return { error: "Email and password are required." };
  }

  const user = await db.query.users.findFirst({
    where: eq(users.email, email),
    columns: { id: true, passwordHash: true },
  });
  if (!user?.passwordHash || !(await verifyPassword(password, user.passwordHash))) {
    return { error: "Invalid email or password." };
  }

  await createSession(user.id);
  await mergeGuestCartIntoUser(user.id);
  redirect(safeNextPath(formData.get("next")) ?? "/account");
}

export async function logoutAction(): Promise<void> {
  await destroySession();
  redirect("/");
}

/**
 * Admin entrance. Only emails on the ADMIN_EMAILS allowlist may proceed.
 * An existing admin signs in with email + password. Creating the admin account
 * (first sign-in) or promoting an existing account also needs ADMIN_SETUP_CODE,
 * so knowing the owner's email is never enough.
 */
export async function adminLoginAction(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  return guarded("adminLoginAction", () => adminLogin(formData));
}

async function adminLogin(formData: FormData): Promise<AuthState> {
  const email = clean(formData.get("email")).toLowerCase();
  const password = String(formData.get("password") ?? "");
  const setupCode = clean(formData.get("setupCode"));

  if (!email || !password) {
    return { error: "Email and password are required." };
  }
  // Don't reveal whether an account exists — non-owners are simply rejected.
  if (!isAdminEmail(email)) {
    return { error: "This account is not authorized for admin access." };
  }

  const existing = await db.query.users.findFirst({
    where: eq(users.email, email),
  });

  if (existing) {
    if (
      !existing.passwordHash ||
      !(await verifyPassword(password, existing.passwordHash))
    ) {
      return { error: "Invalid email or password." };
    }
    if (existing.role !== "admin") {
      if (!isValidAdminSetupCode(setupCode)) {
        return { error: "Enter the admin setup code to activate admin access for this account." };
      }
      await db
        .update(users)
        .set({ role: "admin" })
        .where(eq(users.id, existing.id));
    }
    await createSession(existing.id);
  } else {
    if (!isValidAdminSetupCode(setupCode)) {
      return {
        error: process.env.ADMIN_SETUP_CODE
          ? "First-time sign-in needs the admin setup code."
          : "Admin setup is disabled: ADMIN_SETUP_CODE is not configured on this server.",
      };
    }
    if (password.length < 8) {
      return { error: "Choose a password with at least 8 characters." };
    }
    const [created] = await db
      .insert(users)
      .values({
        email,
        name: "Owner",
        role: "admin",
        passwordHash: await hashPassword(password),
      })
      .returning({ id: users.id });
    await createSession(created.id);
  }

  redirect("/admin");
}
