import Link from "next/link";
import type { Metadata } from "next";
import { Breadcrumbs } from "@/components/catalog/Breadcrumbs";
import { getNavCategories, getTopCategories } from "@/lib/queries";

// DB-backed listing — render at request time, not at build (no DB during build).
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Shop All Categories",
  description: "Browse heavy-duty truck and trailer parts by category.",
};

export default async function CategoriesIndexPage() {
  const cats = await getTopCategories();
  const nav = await getNavCategories();

  return (
    <div className="mx-auto max-w-7xl px-4 py-6">
      <Breadcrumbs items={[{ label: "Categories" }]} />
      <div className="mt-4 border-b-2 border-steel-900 pb-3">
        <h1 className="font-display text-3xl font-bold uppercase tracking-wide text-steel-900">
          Shop All Categories
        </h1>
      </div>

      {cats.length === 0 && (
        <div className="mt-8 rounded-lg border border-dashed border-border bg-surface p-12 text-center">
          <p className="font-display text-lg font-bold text-steel-700">
            Categories are loading
          </p>
          <p className="mt-1 text-sm text-steel-500">
            Our catalog is being set up. Please check back shortly.
          </p>
        </div>
      )}

      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {cats.map((cat) => (
          <div
            key={cat.id}
            className="rounded-lg border border-border bg-white p-5"
          >
            <Link
              href={`/c/${cat.slug}`}
              className="font-display text-lg font-bold text-steel-900 hover:text-brand"
            >
              {cat.name}
            </Link>
            {cat.blurb && (
              <p className="mt-0.5 text-xs text-steel-500">{cat.blurb}</p>
            )}
            <ul className="mt-3 space-y-1.5">
              {(nav.find((n) => n.slug === cat.slug)?.subcategories ?? []).map((sub) => (
                <li key={sub.slug}>
                  <Link
                    href={`/c/${cat.slug}/${sub.slug}`}
                    className="flex justify-between text-sm text-steel-600 hover:text-brand"
                  >
                    <span>{sub.name}</span>
                    <span className="text-xs text-steel-400">{sub.count}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
}
